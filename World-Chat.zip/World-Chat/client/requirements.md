## Packages
socket.io-client | Real-time chat communication
framer-motion | Smooth UI transitions and animations
react-razorpay | Razorpay payment integration wrapper (or script loading)

## Notes
Socket.io connects to / path
Login is username-only (no password)
Premium status requires Razorpay test mode integration
Images are stock/emoji based
