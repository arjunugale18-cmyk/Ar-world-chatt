import type { Express } from "express";
import type { Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import { storage } from "./storage";
import { api, ws } from "@shared/routes";
import { z } from "zod";
import Razorpay from "razorpay";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  const io = new SocketIOServer(httpServer, {
    path: "/socket.io",
    cors: {
      origin: "*",
    },
  });

  // Razorpay instance (Test Mode)
  // In a real app, use process.env.RAZORPAY_KEY_ID
  const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID || "rzp_test_xxxxxxxx",
    key_secret: process.env.RAZORPAY_KEY_SECRET || "xxxxxxxxxxxx",
  });

  // Login (Get or Create)
  app.post(api.users.login.path, async (req, res) => {
    const { username } = api.users.login.input.parse(req.body);
    let user = await storage.getUserByUsername(username);
    if (!user) {
      user = await storage.createUser({ username });
    }
    res.json(user);
  });

  // List Users
  app.get(api.users.list.path, async (req, res) => {
    const users = await storage.getAllUsers();
    res.json(users);
  });

  // Get Premium Status
  app.get(api.users.getPremium.path, async (req, res) => {
    const { username } = req.params;
    const user = await storage.getUserByUsername(username);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json({ premium: user.isPremium });
  });

  // Create Order
  app.post(api.payment.createOrder.path, async (req, res) => {
    try {
      const order = await razorpay.orders.create({
        amount: 2900, // ₹29.00
        currency: "INR",
        receipt: "receipt_" + Date.now(),
      });
      res.json(order);
    } catch (error) {
      console.error("Razorpay error:", error);
      // Fallback for test mode if keys are invalid
      res.json({
        id: "order_test_" + Date.now(),
        amount: 2900,
        currency: "INR",
      });
    }
  });

  // Payment Success
  app.post(api.payment.success.path, async (req, res) => {
    const { username } = api.payment.success.input.parse(req.body);
    await storage.updateUserPremium(username, true);
    res.json({ success: true });
  });

  // Socket.io Logic
  io.on("connection", (socket) => {
    console.log("New client connected", socket.id);

    socket.on(ws.events.SEND_MESSAGE, async (data) => {
      // data: { from, to, msg }
      // Persist message
      try {
         await storage.createMessage({
          fromUsername: data.from,
          toUsername: data.to,
          content: data.msg,
        });
        
        // Emit to everyone (simple broadcasting, client filters)
        // In a real app, use rooms: socket.join(username)
        io.emit(ws.events.NEW_MESSAGE, data);
      } catch (e) {
        console.error("Message error:", e);
      }
    });

    socket.on("disconnect", () => {
      console.log("Client disconnected");
    });
  });

  return httpServer;
}
